**To delete an AWS Config rule**

The following command deletes an AWS Config rule named ``MyConfigRule``::

    aws configservice delete-config-rule --config-rule-name MyConfigRule